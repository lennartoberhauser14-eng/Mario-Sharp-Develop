﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Spinne_Laufen
{
	public partial class MainForm : Form
	{ 	private Bitmap[] Bild=new Bitmap[4];
		private Image Hintergrund;
		private int Nr=0;
		private Random rand=new Random();
		private int x,y;
		private int punktx,punkty;
		private const int punktz=13;
		public MainForm()
		{
			InitializeComponent();
		}
		void MainForm_Load(object sender, EventArgs e)
		{

			this.DoubleBuffered=true;
			Bild[0]=(Bitmap)Image.FromFile("mario.png");
			Bild[3]=(Bitmap)Image.FromFile("mario_springt.png");
			Hintergrund=Image.FromFile("mariohintergrund.jpg");
			SpinImage();
		}
		void FromMainPaint(object sender, PaintEventArgs e)
		{
			Graphics Grafik=e.Graphics;
			int camX=x+100-this.ClientSize.Width/2;
			int camY=y+100-this.ClientSize.Height/2;

			int bw=Hintergrund.Width*this.ClientSize.Height/Hintergrund.Height;
			int versatz=((int)(camX*0.5)%bw+bw)%bw;
			for (int bx=-versatz; bx<this.ClientSize.Width; bx+=bw)
				Grafik.DrawImage(Hintergrund, bx, 0, bw, this.ClientSize.Height);

			Grafik.DrawImage(Bild[Nr], x-camX,y-camY,50,50);
			Grafik.FillEllipse(Brushes.Black, punktx-camX,punkty-camY,punktz,punktz);
		}
		private void SpinImage()
		{
			for (int i = 1; i < 3; i++) Bild[i]=(Bitmap)Bild[0].Clone();
			Bild[2].RotateFlip(RotateFlipType.Rotate180FlipY);
		}
		void MainFormKDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode==Keys.Left){Nr=2; x-=5;}
			if (e.KeyCode==Keys.Right){Nr=0; x+=5;}
			if (e.KeyCode==Keys.Up){Nr=3; y-=5;}
			this.Invalidate();
		}

	}
}

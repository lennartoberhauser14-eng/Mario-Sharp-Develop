using System;
using System.Collections.Generic;
using System.Drawing;

namespace MarioJumpAndRun
{
	public class Level
	{
		public const int Tile=16;
		public const int Scale=3;

		static string[] map={
			"                                                                                                                                                                                                                    ",
			"                                                                                                                                                                                                                    ",
			"                                                                                                                                                                                                      F             ",
			"                                                                                                                                                                                                      F             ",
			"                                                                                g g                                                                                                                   F             ",
			"                      ?                                                         BBBBBBBB   BBB?              M           BBB    B??B                                                        XX        F             ",
			"                                                                                                                                                                                           XXX        F             ",
			"                                                                                                                                                                                          XXXX        F             ",
			"                                                                                                                                                                                         XXXXX        F   C         ",
			"                ?   BMB?B                     []         []                  BMB              B     BB    ?  ?  ?     B          BB      X  X          XX  X            BB?B            XXXXXX        F             ",
			"                                      []      {}         {}                                                                             XX  XX        XXX  XX                          XXXXXXX        F             ",
			"                            []        {}      {}         {}                                                                            XXX  XXX      XXXX  XXX     []              [] XXXXXXXX        F             ",
			"                      g     {}        {}g     {}   g g   {}                                      g g       g      g g       g g g g   XXXX  XXXX    XXXXX  XXXX    {}         g g  {}XXXXXXXXX        X             ",
			"#####################################################################  ###############   ################################################################  #########################################################",
			"#####################################################################  ###############   ################################################################  #########################################################"
		};
		static int[] blink={1,1,1,2,3,2};

		char[,] tiles;
		public int Width;
		public int Height;
		public int FlagColumn;
		public int FlagRow=-1;
		public int CastleColumn;
		public int CastleRow;
		public float FlagOffset=0;
		public List<Goomba> Goombas=new List<Goomba>();
		int bumpColumn=-1;
		int bumpRow=0;
		int bumpTimer=0;

		public Level()
		{
			Height=map.Length;
			Width=map[0].Length;
			tiles=new char[Width,Height];
			for(int row=0;row<Height;row++) {
				for(int column=0;column<Width;column++) {
					char c=map[row][column];
					if(c=='g') {
						Goombas.Add(new Goomba(column*Tile,row*Tile));
						c=' ';
					}
					if(c=='C') {
						CastleColumn=column;
						CastleRow=row;
						c=' ';
					}
					if(c=='F'&&FlagRow<0) {
						FlagColumn=column;
						FlagRow=row;
					}
					tiles[column,row]=c;
				}
			}
		}

		public char Get(int column,int row)
		{
			if(column<0||column>=Width) return '#';
			if(row<0||row>=Height) return ' ';
			return tiles[column,row];
		}

		public bool IsSolid(int column,int row)
		{
			char c=Get(column,row);
			return c!=' '&&c!='F';
		}

		public bool Collides(float x,float y,float width,float height)
		{
			int column1=(int)Math.Floor(x/Tile);
			int column2=(int)Math.Floor((x+width-0.01f)/Tile);
			int row1=(int)Math.Floor(y/Tile);
			int row2=(int)Math.Floor((y+height-0.01f)/Tile);
			for(int column=column1;column<=column2;column++) {
				for(int row=row1;row<=row2;row++) {
					if(IsSolid(column,row)) return true;
				}
			}
			return false;
		}

		public char Bump(int column,int row)
		{
			char c=Get(column,row);
			if(c!='?'&&c!='M'&&c!='B') return ' ';
			if(c!='B') tiles[column,row]='E';
			bumpColumn=column;
			bumpRow=row;
			bumpTimer=8;
			return c;
		}

		public void Update()
		{
			if(bumpTimer>0) bumpTimer--;
		}

		string SpriteName(int column,int row,int frame)
		{
			switch(tiles[column,row]) {
				case '#': return "ground";
				case 'B': return "brick";
				case 'X': return "hard_block";
				case '?':
				case 'M': return "question"+blink[frame/8%6];
				case 'E': return "question_empty";
				case '[': return "pipe_top_left";
				case ']': return "pipe_top_right";
				case '{': return "pipe_left";
				case '}': return "pipe_right";
				case 'F': return row==FlagRow?"pole_top":"pole";
			}
			return null;
		}

		public void Draw(Graphics g,int offset,int frame)
		{
			Sprites.Draw(g,"castle",CastleColumn*Tile*Scale-offset,CastleRow*Tile*Scale);
			int first=offset/(Tile*Scale);
			for(int column=first;column<=first+16&&column<Width;column++) {
				for(int row=0;row<Height;row++) {
					string name=SpriteName(column,row,frame);
					if(name==null) continue;
					int y=row*Tile*Scale;
					if(column==bumpColumn&&row==bumpRow) y-=(4-Math.Abs(4-bumpTimer))*Scale;
					Sprites.Draw(g,name,column*Tile*Scale-offset,y);
				}
			}
			Sprites.Draw(g,"flag",(FlagColumn*Tile-8)*Scale-offset,(int)(((FlagRow+1)*Tile+FlagOffset)*Scale));
		}
	}
}

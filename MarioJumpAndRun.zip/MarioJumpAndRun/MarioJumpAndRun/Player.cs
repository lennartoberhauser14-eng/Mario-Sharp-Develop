using System;
using System.Drawing;

namespace MarioJumpAndRun
{
	public class Player
	{
		public const int Width=12;

		public float X;
		public float Y;
		public float VelocityX=0;
		public float VelocityY=0;
		public bool Big=false;
		public bool OnGround=true;
		public bool FacingLeft=false;
		public bool Skidding=false;
		public bool Dead=false;
		public bool Hidden=false;
		public int DeadTimer=0;
		public int GrowTimer=0;
		public int Invincible=0;
		public int Combo=0;
		public int BumpColumn=-1;
		public int BumpRow=0;
		bool jumpHeld=true;
		float riseGravity=0.125f;
		float fallGravity=0.4375f;
		float walk=0;

		public Player(float x,float y)
		{
			X=x;
			Y=y;
		}

		public int Height
		{
			get { return Big?32:16; }
		}

		public RectangleF Bounds
		{
			get { return new RectangleF(X,Y,Width,Height); }
		}

		public void Update(Level level,bool left,bool right,bool run,bool jump,float minX)
		{
			float max=run?2.5625f:1.5625f;
			int direction=(right?1:0)-(left?1:0);
			Skidding=false;
			if(direction!=0) {
				if(VelocityX*direction<0) {
					Skidding=OnGround;
					VelocityX+=direction*0.1016f;
				} else {
					VelocityX+=direction*(run?0.0557f:0.0371f);
				}
				if(OnGround) FacingLeft=direction<0;
			} else if(OnGround) {
				if(Math.Abs(VelocityX)<0.0508f) VelocityX=0;
				else VelocityX-=Math.Sign(VelocityX)*0.0508f;
			}
			if(VelocityX>max) VelocityX=Math.Max(max,VelocityX-0.0508f);
			if(VelocityX<-max) VelocityX=Math.Min(-max,VelocityX+0.0508f);

			if(jump&&!jumpHeld&&OnGround) {
				float speed=Math.Abs(VelocityX);
				VelocityY=speed<2.3125f?-4:-5;
				riseGravity=speed<1?0.125f:speed<2.3125f?0.1172f:0.15625f;
				fallGravity=speed<1?0.4375f:speed<2.3125f?0.375f:0.5625f;
			}
			jumpHeld=jump;

			X+=VelocityX;
			if(X<minX) {
				X=minX;
				if(VelocityX<0) VelocityX=0;
			}
			if(VelocityX!=0&&level.Collides(X,Y,Width,Height)) {
				if(VelocityX>0) X=(float)Math.Floor((X+Width)/Level.Tile)*Level.Tile-Width;
				else X=(float)Math.Floor(X/Level.Tile)*Level.Tile+Level.Tile;
				VelocityX=0;
			}

			Y+=VelocityY;
			OnGround=false;
			BumpColumn=-1;
			if(level.Collides(X,Y,Width,Height)) {
				if(VelocityY>=0) {
					Y=(float)Math.Floor((Y+Height)/Level.Tile)*Level.Tile-Height;
					OnGround=true;
					Combo=0;
				} else {
					Y=(float)Math.Floor(Y/Level.Tile)*Level.Tile+Level.Tile;
					BumpRow=(int)Math.Floor(Y/Level.Tile)-1;
					BumpColumn=(int)((X+Width/2)/Level.Tile);
					if(!level.IsSolid(BumpColumn,BumpRow)) {
						BumpColumn=(int)(X/Level.Tile);
						if(!level.IsSolid(BumpColumn,BumpRow)) BumpColumn++;
					}
				}
				VelocityY=0;
			}
			VelocityY+=jump&&VelocityY<0?riseGravity:fallGravity;
			if(VelocityY>4.5f) VelocityY=4;

			walk+=Math.Abs(VelocityX);
			if(Invincible>0) Invincible--;
		}

		public void UpdateDead()
		{
			DeadTimer++;
			if(DeadTimer<30) return;
			VelocityY+=0.25f;
			Y+=VelocityY;
		}

		public void Grow()
		{
			if(Big) return;
			Big=true;
			Y-=16;
			GrowTimer=45;
		}

		public void Shrink()
		{
			Big=false;
			Y+=16;
			Invincible=120;
		}

		public void Die()
		{
			if(Big) Y+=16;
			Big=false;
			Dead=true;
			DeadTimer=0;
			VelocityY=-4.5f;
		}

		string SpriteName()
		{
			if(Dead) return "mario_small_dead";
			if(GrowTimer>0) {
				int phase=GrowTimer/5%3;
				return phase==0?"mario_big_stand":phase==1?"mario_grow":"mario_small_stand";
			}
			string size=Big?"mario_big_":"mario_small_";
			if(!OnGround) return size+"jump";
			if(Skidding) return size+"skid";
			if(VelocityX!=0) return size+"run"+((int)(walk/5)%3+1);
			return size+"stand";
		}

		public void Draw(Graphics g,int offset)
		{
			if(Hidden||Invincible/3%2==1) return;
			string name=SpriteName();
			if(FacingLeft!=Skidding) name+="_flipped";
			int x=(int)((X-2)*Level.Scale)-offset;
			int y=(int)((Y+Height)*Level.Scale)-Sprites.Get(name).Height;
			Sprites.Draw(g,name,x,y);
		}
	}
}

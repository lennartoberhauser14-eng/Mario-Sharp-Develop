using System;

namespace MarioJumpAndRun
{
	public class Player
	{
		public float X,Y,SpeedX,SpeedY;
		public bool Big,OnGround,FacingLeft,Skidding;
		public int Invincible;
		public int BumpCol=-1,BumpRow=-1;
		private bool jumpHeld=true;
		private float walkFrame;
		private int[] walkCycle={1,2,3,2};

		public Player(float x, float y)
		{
			X=x;
			Y=y;
			OnGround=true;
		}

		public int Width
		{
			get{return 12;}
		}

		public int Height
		{
			get{if (Big) return 32; return 16;}
		}

		public void Move(bool left, bool right, bool jump, Level level)
		{
			Skidding=false;
			if (right&&!left)
			{
				FacingLeft=false;
				if (SpeedX<0){SpeedX+=0.15f; Skidding=OnGround;}
				else SpeedX=Math.Min(1.5f,SpeedX+0.06f);
			}
			else if (left&&!right)
			{
				FacingLeft=true;
				if (SpeedX>0){SpeedX-=0.15f; Skidding=OnGround;}
				else SpeedX=Math.Max(-1.5f,SpeedX-0.06f);
			}
			else if (OnGround)
			{
				if (SpeedX>0) SpeedX=Math.Max(0,SpeedX-0.07f);
				else SpeedX=Math.Min(0,SpeedX+0.07f);
			}

			if (jump&&!jumpHeld&&OnGround){SpeedY=-5.6f; OnGround=false;}
			jumpHeld=jump;
			if (jump&&SpeedY<0) SpeedY+=0.19f;
			else SpeedY+=0.5f;
			if (SpeedY>4.5f) SpeedY=4.5f;

			X+=SpeedX;
			if (level.HitsSolid(X,Y,Width,Height))
			{
				if (SpeedX>0) X=(float)Math.Floor((X+Width)/16)*16-Width;
				else X=(float)Math.Floor(X/16)*16+16;
				SpeedX=0;
			}

			Y+=SpeedY;
			OnGround=false;
			BumpCol=-1;
			if (level.HitsSolid(X,Y,Width,Height))
			{
				if (SpeedY>0){Y=(float)Math.Floor((Y+Height)/16)*16-Height; OnGround=true;}
				else
				{
					BumpRow=(int)Math.Floor(Y/16);
					BumpCol=FindBumpColumn(BumpRow,level);
					Y=BumpRow*16+16;
				}
				SpeedY=0;
			}
			if (OnGround) walkFrame+=Math.Abs(SpeedX)/5f;
		}

		int FindBumpColumn(int row, Level level)
		{
			int middle=(int)Math.Floor((X+Width/2f)/16);
			int left=(int)Math.Floor(X/16);
			if (level.IsSolid(middle,row)) return middle;
			if (level.IsSolid(left,row)) return left;
			return (int)Math.Floor((X+Width-0.01f)/16);
		}

		public int GetImageNumber()
		{
			if (!OnGround) return 4;
			if (Skidding) return 5;
			if (Math.Abs(SpeedX)<0.1f){walkFrame=0; return 0;}
			return walkCycle[(int)walkFrame%4];
		}
	}
}

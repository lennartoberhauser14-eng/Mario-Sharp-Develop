using System;
using System.Drawing;

namespace MarioJumpAndRun
{
	public class Coin
	{
		public float X;
		public float Y;
		public float VelocityY=-5;
		public bool Removed=false;
		int timer=0;

		public Coin(float x,float y)
		{
			X=x;
			Y=y;
		}

		public void Update()
		{
			Y+=VelocityY;
			VelocityY+=0.4f;
			timer++;
			if(timer>22) Removed=true;
		}

		public void Draw(Graphics g,int offset)
		{
			Sprites.Draw(g,"coin"+(timer/3%4+1),(int)(X*Level.Scale)-offset,(int)(Y*Level.Scale));
		}
	}
}

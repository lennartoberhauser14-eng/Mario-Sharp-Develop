using System;

namespace MarioJumpAndRun
{
	public class Coin
	{
		public float X,Y;
		public float SpeedY=-5f;
		public bool Removed;
		private int timer;

		public Coin(int col, int row)
		{
			X=col*16;
			Y=row*16-16;
		}

		public void Move()
		{
			timer++;
			Y+=SpeedY;
			SpeedY+=0.3f;
			if (timer>30) Removed=true;
		}

		public int GetImageNumber()
		{
			return timer/3%4;
		}
	}
}

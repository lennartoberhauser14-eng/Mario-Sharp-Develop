using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Windows.Forms;

namespace MarioJumpAndRun
{
	public partial class MainForm : Form
	{
		private Level level=new Level();
		private Player player;
		private List<Goomba> goombas=new List<Goomba>();
		private List<Mushroom> mushrooms=new List<Mushroom>();
		private List<Coin> coins=new List<Coin>();
		private Bitmap[] marioSmall=new Bitmap[7], marioSmallLeft=new Bitmap[7];
		private Bitmap[] marioBig=new Bitmap[6], marioBigLeft=new Bitmap[6];
		private Bitmap[] goombaImage=new Bitmap[3], questionBlock=new Bitmap[3], coinImage=new Bitmap[4];
		private Bitmap ground,groundTop,brick,usedBlock,pipeTopLeft,pipeTopRight,pipeLeft,pipeRight;
		private Bitmap mushroomImage,flag,flagPole,flagTop,background;
		private Bitmap screen=new Bitmap(256,240,PixelFormat.Format32bppPArgb);
		private Font hudFont=new Font("Consolas",22,FontStyle.Bold,GraphicsUnit.Pixel);
		private Font titleFont=new Font("Consolas",56,FontStyle.Bold,GraphicsUnit.Pixel);
		private string state="title";
		private int stateTimer,tick,score,coinCount,highScore;
		private int bumpCol=-1,bumpRow,bumpTimer;
		private float cameraX,flagY;
		private bool leftDown,rightDown,jumpDown,jumpWasDown;
		private int[] blink={0,0,0,1,2,1};

		public MainForm()
		{
			InitializeComponent();
		}

		void MainForm_Load(object sender, EventArgs e)
		{
			this.DoubleBuffered=true;
			LoadImages();
			FlipImages();
			ScaleBackground();
			ResetLevel();
			timer1.Interval=15;
			timer1.Start();
		}

		void LoadImages()
		{
			string folder=Application.StartupPath+@"\Images\";
			if (!Directory.Exists(folder))
			{
				MessageBox.Show("Folder not found: "+folder,"Error");
				Environment.Exit(0);
			}
			string[] frames={"stand","walk1","walk2","walk3","jump","skid","dead"};
			for (int i = 0; i < 7; i++) marioSmall[i]=LoadImage("mario_small_"+frames[i]);
			for (int i = 0; i < 6; i++) marioBig[i]=LoadImage("mario_big_"+frames[i]);
			for (int i = 0; i < 3; i++) questionBlock[i]=LoadImage("block_question"+(i+1));
			for (int i = 0; i < 4; i++) coinImage[i]=LoadImage("coin"+(i+1));
			goombaImage[0]=LoadImage("goomba_walk1");
			goombaImage[1]=LoadImage("goomba_walk2");
			goombaImage[2]=LoadImage("goomba_flat");
			ground=LoadImage("ground");
			groundTop=LoadImage("ground_top");
			brick=LoadImage("brick");
			usedBlock=LoadImage("block_used");
			pipeTopLeft=LoadImage("pipe_top_left");
			pipeTopRight=LoadImage("pipe_top_right");
			pipeLeft=LoadImage("pipe_left");
			pipeRight=LoadImage("pipe_right");
			mushroomImage=LoadImage("mushroom");
			flag=LoadImage("flag");
			flagPole=LoadImage("flag_pole");
			flagTop=LoadImage("flag_top");
			if (File.Exists(folder+"background.png")) background=LoadImage("background");
			else background=CreatePlaceholderBackground();
		}

		Bitmap LoadImage(string name)
		{
			return (Bitmap)Image.FromFile(Application.StartupPath+@"\Images\"+name+".png");
		}

		void FlipImages()
		{
			for (int i = 0; i < 7; i++)
			{
				marioSmallLeft[i]=(Bitmap)marioSmall[i].Clone();
				marioSmallLeft[i].RotateFlip(RotateFlipType.RotateNoneFlipX);
			}
			for (int i = 0; i < 6; i++)
			{
				marioBigLeft[i]=(Bitmap)marioBig[i].Clone();
				marioBigLeft[i].RotateFlip(RotateFlipType.RotateNoneFlipX);
			}
		}

		Bitmap CreatePlaceholderBackground()
		{
			Bitmap image=new Bitmap(256,240);
			Graphics graphic=Graphics.FromImage(image);
			graphic.Clear(Color.FromArgb(143,199,255));
			graphic.FillEllipse(new SolidBrush(Color.FromArgb(70,160,80)),-30,170,140,90);
			graphic.FillEllipse(new SolidBrush(Color.FromArgb(108,196,106)),150,185,90,60);
			graphic.FillEllipse(Brushes.White,30,40,40,14);
			graphic.FillEllipse(Brushes.White,44,32,24,16);
			graphic.FillEllipse(Brushes.White,160,60,48,14);
			graphic.FillEllipse(Brushes.White,176,52,24,14);
			return image;
		}

		void ScaleBackground()
		{
			int width=background.Width*this.ClientSize.Height/background.Height;
			Bitmap scaled=new Bitmap(width,this.ClientSize.Height,PixelFormat.Format32bppPArgb);
			Graphics graphic=Graphics.FromImage(scaled);
			graphic.InterpolationMode=InterpolationMode.NearestNeighbor;
			graphic.PixelOffsetMode=PixelOffsetMode.Half;
			graphic.DrawImage(background,0,0,width,this.ClientSize.Height);
			background=scaled;
		}

		void ResetLevel()
		{
			level.Load();
			player=new Player(level.PlayerStart.X*16+2,level.PlayerStart.Y*16);
			goombas.Clear();
			foreach (Point start in level.GoombaStarts) goombas.Add(new Goomba(start.X,start.Y));
			mushrooms.Clear();
			coins.Clear();
			cameraX=0;
			flagY=50;
			bumpTimer=0;
		}

		void StartGame()
		{
			score=0;
			coinCount=0;
			ResetLevel();
			state="playing";
		}

		void Timer1Tick(object sender, EventArgs e)
		{
			UpdateGame();
			this.Invalidate();
		}

		void UpdateGame()
		{
			tick++;
			if (state=="title"&&jumpDown&&!jumpWasDown) StartGame();
			else if (state=="playing") UpdatePlaying();
			else if (state=="growing"||state=="shrinking")
			{
				stateTimer--;
				if (stateTimer<=0) state="playing";
			}
			else if (state=="dying") UpdateDying();
			else if (state=="won") UpdateWon();
			jumpWasDown=jumpDown;
		}

		void UpdatePlaying()
		{
			player.Move(leftDown,rightDown,jumpDown,level);
			if (player.BumpCol>=0) BumpBlock(player.BumpCol,player.BumpRow);
			MoveCamera();
			if (player.Invincible>0) player.Invincible--;
			if (bumpTimer>0) bumpTimer--;

			foreach (Goomba goomba in goombas)
			{
				goomba.Active=goomba.X>cameraX-32&&goomba.X<cameraX+272;
				if (goomba.Active){goomba.Move(level); CheckGoomba(goomba);}
			}
			goombas.RemoveAll(g => g.Removed);

			foreach (Mushroom mushroom in mushrooms)
			{
				mushroom.Move(level);
				if (mushroom.RiseTimer==0&&Overlaps(player.X,player.Y,player.Width,player.Height,mushroom.X,mushroom.Y,16,16))
				{
					mushroom.Removed=true;
					Grow();
				}
			}
			mushrooms.RemoveAll(m => m.Removed);

			foreach (Coin coin in coins) coin.Move();
			coins.RemoveAll(c => c.Removed);

			if (state!="playing") return;
			if (player.Y>level.Rows*16) Die();
			else if (player.X+player.Width>=level.FlagColumn*16) Win();
		}

		void MoveCamera()
		{
			float target=player.X+player.Width/2f-128;
			float maxCamera=level.Columns*16-256;
			cameraX=Math.Max(0,Math.Min(target,maxCamera));
		}

		void BumpBlock(int col, int row)
		{
			char tile=level.GetTile(col,row);
			if (tile=='?')
			{
				level.SetTile(col,row,'U');
				coins.Add(new Coin(col,row));
				coinCount++;
				score+=200;
			}
			if (tile=='M')
			{
				level.SetTile(col,row,'U');
				mushrooms.Add(new Mushroom(col,row));
			}
			if (tile=='?'||tile=='M'||tile=='B'){bumpCol=col; bumpRow=row; bumpTimer=8;}
		}

		void CheckGoomba(Goomba goomba)
		{
			if (goomba.Flat||state!="playing") return;
			if (!Overlaps(player.X,player.Y,player.Width,player.Height,goomba.X+2,goomba.Y+4,12,12)) return;
			if (player.SpeedY>0&&player.Y+player.Height<goomba.Y+12)
			{
				goomba.Stomp();
				player.SpeedY=jumpDown?-4f:-2.5f;
				score+=100;
			}
			else if (player.Invincible==0) Hurt();
		}

		bool Overlaps(float x1, float y1, float w1, float h1, float x2, float y2, float w2, float h2)
		{
			return x1<x2+w2&&x2<x1+w1&&y1<y2+h2&&y2<y1+h1;
		}

		void Grow()
		{
			score+=1000;
			if (player.Big) return;
			player.Big=true;
			player.Y-=16;
			state="growing";
			stateTimer=48;
		}

		void Hurt()
		{
			if (!player.Big){Die(); return;}
			player.Big=false;
			player.Y+=16;
			player.Invincible=120;
			state="shrinking";
			stateTimer=48;
		}

		void Die()
		{
			state="dying";
			stateTimer=0;
			player.Big=false;
			player.SpeedY=-4f;
			if (score>highScore) highScore=score;
		}

		void UpdateDying()
		{
			stateTimer++;
			if (stateTimer>30){player.Y+=player.SpeedY; player.SpeedY+=0.25f;}
			if (stateTimer>150)
			{
				score=0;
				coinCount=0;
				ResetLevel();
				state="playing";
			}
		}

		void Win()
		{
			state="won";
			stateTimer=0;
			player.SpeedX=0;
			player.SpeedY=0;
			player.FacingLeft=false;
			player.X=level.FlagColumn*16+6-player.Width;
			if (player.Y<80) score+=5000;
			else if (player.Y<112) score+=2000;
			else if (player.Y<144) score+=800;
			else if (player.Y<176) score+=400;
			else score+=100;
		}

		void UpdateWon()
		{
			stateTimer++;
			if (flagY<176) flagY+=2;
			if (stateTimer<=90) player.Y=Math.Min(player.Y+2,192-player.Height);
			else
			{
				player.Move(false,true,false,level);
				MoveCamera();
			}
			if (stateTimer>300)
			{
				if (score>highScore) highScore=score;
				ResetLevel();
				state="title";
			}
		}

		void MainFormPaint(object sender, PaintEventArgs e)
		{
			DrawWorld();
			Graphics graphic=e.Graphics;
			graphic.InterpolationMode=InterpolationMode.NearestNeighbor;
			graphic.PixelOffsetMode=PixelOffsetMode.Half;
			int bw=background.Width;
			int offset=((int)(cameraX*this.ClientSize.Width/256*0.5)%bw+bw)%bw;
			for (int bx=-offset; bx<this.ClientSize.Width; bx+=bw)
				graphic.DrawImageUnscaled(background,bx,0);
			graphic.DrawImage(screen,0,0,this.ClientSize.Width,this.ClientSize.Height);
			DrawHud(graphic);
		}

		void DrawWorld()
		{
			Graphics graphic=Graphics.FromImage(screen);
			graphic.Clear(Color.Transparent);
			int camX=(int)cameraX;

			foreach (Mushroom mushroom in mushrooms) Draw(graphic,mushroomImage,mushroom.X-camX,mushroom.Y);

			int firstCol=camX/16;
			for (int col = firstCol; col <= firstCol+16; col++)
			{
				for (int row = 0; row < level.Rows; row++)
				{
					Bitmap image=GetTileImage(col,row);
					if (image==null) continue;
					int y=row*16;
					if (col==bumpCol&&row==bumpRow&&bumpTimer>0) y-=4-Math.Abs(bumpTimer-4);
					Draw(graphic,image,col*16-camX,y);
				}
			}

			int poleX=level.FlagColumn*16-camX;
			Draw(graphic,flagTop,poleX,32);
			for (int row = 3; row < 12; row++) Draw(graphic,flagPole,poleX,row*16);
			Draw(graphic,flag,poleX-10,flagY);

			foreach (Goomba goomba in goombas) Draw(graphic,goombaImage[goomba.GetImageNumber()],goomba.X-camX,goomba.Y);
			foreach (Coin coin in coins) Draw(graphic,coinImage[coin.GetImageNumber()],coin.X-camX,coin.Y);
			DrawPlayer(graphic,camX);
			graphic.Dispose();
		}

		void DrawPlayer(Graphics graphic, int camX)
		{
			if (player.Invincible>0&&player.Invincible/4%2==1&&state=="playing") return;
			Bitmap image;
			if (state=="growing"||state=="shrinking")
			{
				if (stateTimer/6%2==0) image=marioBig[0];
				else image=marioSmall[0];
			}
			else if (state=="dying") image=marioSmall[6];
			else if (player.Big&&player.FacingLeft) image=marioBigLeft[player.GetImageNumber()];
			else if (player.Big) image=marioBig[player.GetImageNumber()];
			else if (player.FacingLeft) image=marioSmallLeft[player.GetImageNumber()];
			else image=marioSmall[player.GetImageNumber()];
			Draw(graphic,image,player.X-2-camX,player.Y+player.Height-image.Height);
		}

		Bitmap GetTileImage(int col, int row)
		{
			if (col>=level.Columns) return null;
			char tile=level.GetTile(col,row);
			if (tile=='#'&&level.GetTile(col,row-1)=='#') return ground;
			if (tile=='#') return groundTop;
			if (tile=='B') return brick;
			if (tile=='?'||tile=='M') return questionBlock[blink[tick/8%6]];
			if (tile=='U'||tile=='H') return usedBlock;
			if (tile=='<') return pipeTopLeft;
			if (tile=='>') return pipeTopRight;
			if (tile=='[') return pipeLeft;
			if (tile==']') return pipeRight;
			return null;
		}

		void Draw(Graphics graphic, Bitmap image, float x, float y)
		{
			graphic.DrawImage(image,new Rectangle((int)Math.Round(x),(int)Math.Round(y),image.Width,image.Height));
		}

		void DrawHud(Graphics graphic)
		{
			graphic.TextRenderingHint=TextRenderingHint.AntiAliasGridFit;
			int w=this.ClientSize.Width;
			DrawText(graphic,"SCORE "+score.ToString("000000"),hudFont,24,12,false);
			DrawText(graphic,"COINS x"+coinCount.ToString("00"),hudFont,w/2,12,true);
			DrawText(graphic,"HI "+highScore.ToString("000000"),hudFont,w-196,12,false);
			if (state=="title")
			{
				graphic.FillRectangle(new SolidBrush(Color.FromArgb(150,0,0,0)),84,170,w-168,300);
				DrawText(graphic,"SUPER MARIO",titleFont,w/2,200,true);
				DrawText(graphic,"HI-SCORE "+highScore.ToString("000000"),hudFont,w/2,300,true);
				if (tick/30%2==0) DrawText(graphic,"PRESS UP TO START",hudFont,w/2,360,true);
				DrawText(graphic,"LEFT RIGHT MOVE  UP JUMP",hudFont,w/2,420,true);
			}
			if (state=="won"&&stateTimer>90) DrawText(graphic,"COURSE CLEAR!",titleFont,w/2,250,true);
		}

		void DrawText(Graphics graphic, string text, Font font, float x, float y, bool center)
		{
			if (center) x-=graphic.MeasureString(text,font).Width/2;
			graphic.DrawString(text,font,Brushes.Black,x+3,y+3);
			graphic.DrawString(text,font,Brushes.White,x,y);
		}

		void MainFormKDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode==Keys.Left) leftDown=true;
			if (e.KeyCode==Keys.Right) rightDown=true;
			if (e.KeyCode==Keys.Up) jumpDown=true;
			if (e.KeyCode==Keys.Escape) this.Close();
		}

		void MainFormKUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode==Keys.Left) leftDown=false;
			if (e.KeyCode==Keys.Right) rightDown=false;
			if (e.KeyCode==Keys.Up) jumpDown=false;
		}

		void MainFormDeactivate(object sender, EventArgs e)
		{
			leftDown=false;
			rightDown=false;
			jumpDown=false;
		}
	}
}

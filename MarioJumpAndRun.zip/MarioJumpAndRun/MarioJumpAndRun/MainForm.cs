using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MarioJumpAndRun
{
	public partial class MainForm : Form
	{
		const string glyphs="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-*";
		static int[] stompScores={100,200,400,500,800,1000,2000,4000,5000,8000};

		Level level;
		Player player;
		List<Goomba> goombas;
		List<Mushroom> mushrooms=new List<Mushroom>();
		List<Coin> coins=new List<Coin>();
		Brush boardBrush=new SolidBrush(Color.FromArgb(200,76,12));
		Brush lightBrush=new SolidBrush(Color.FromArgb(252,188,176));
		bool playing=false;
		bool finished=false;
		bool left=false;
		bool right=false;
		bool run=false;
		bool jump=false;
		int score=0;
		int highScore=0;
		int coinCount=0;
		int time=400;
		int frame=0;
		int finishStep=0;
		int finishTimer=0;
		float cameraX=0;

		public MainForm()
		{
			InitializeComponent();
			DoubleBuffered=true;
			StartLevel();
		}

		void StartLevel()
		{
			level=new Level();
			player=new Player(40,(level.Height-3)*Level.Tile);
			goombas=level.Goombas;
			mushrooms.Clear();
			coins.Clear();
			score=0;
			coinCount=0;
			time=400;
			cameraX=0;
			finished=false;
			finishStep=0;
			finishTimer=0;
		}

		void Timer1Tick(object sender,EventArgs e)
		{
			frame++;
			if(playing) UpdateGame();
			if(score>highScore) highScore=score;
			Invalidate();
		}

		void UpdateGame()
		{
			if(player.GrowTimer>0) {
				player.GrowTimer--;
				return;
			}
			level.Update();
			if(player.Dead) {
				player.UpdateDead();
				if(player.DeadTimer>150) StartLevel();
				return;
			}
			if(finished) {
				UpdateFinish();
				return;
			}
			if(frame%24==0) {
				time--;
				if(time<=0) {
					time=0;
					player.Die();
					return;
				}
			}

			player.Update(level,left,right,run,jump,cameraX);
			if(player.BumpColumn>=0) HitBlock(player.BumpColumn,player.BumpRow);
			if(player.Y>level.Height*Level.Tile+48) {
				player.Die();
				return;
			}

			foreach(Mushroom mushroom in mushrooms) {
				mushroom.Update(level);
				if(mushroom.Bounds.IntersectsWith(player.Bounds)) {
					mushroom.Removed=true;
					score+=1000;
					player.Grow();
				}
			}
			foreach(Goomba goomba in goombas) {
				if(goomba.X<cameraX+272) goomba.Active=true;
				if(!goomba.Active) continue;
				goomba.Update(level);
				if(!goomba.Alive||player.Dead||!goomba.Bounds.IntersectsWith(player.Bounds)) continue;
				if(player.VelocityY>0&&player.Y+player.Height<goomba.Y+10) {
					goomba.Flat=true;
					player.VelocityY=-4;
					score+=stompScores[Math.Min(player.Combo,stompScores.Length-1)];
					player.Combo++;
				} else if(player.Invincible==0) {
					if(player.Big) player.Shrink();
					else player.Die();
				}
			}
			for(int i=0;i<goombas.Count;i++) {
				for(int j=i+1;j<goombas.Count;j++) {
					Goomba a=goombas[i];
					Goomba b=goombas[j];
					if(!a.Alive||!b.Alive||!a.Bounds.IntersectsWith(b.Bounds)) continue;
					a.VelocityX=a.X<b.X?-0.5f:0.5f;
					b.VelocityX=-a.VelocityX;
				}
			}
			foreach(Coin coin in coins) coin.Update();
			mushrooms.RemoveAll(mushroom=>mushroom.Removed);
			goombas.RemoveAll(goomba=>goomba.Removed);
			coins.RemoveAll(coin=>coin.Removed);

			if(!player.Dead&&player.X+Player.Width>=level.FlagColumn*Level.Tile+6) {
				finished=true;
				player.X=level.FlagColumn*Level.Tile+7-Player.Width;
				player.VelocityX=0;
				player.VelocityY=0;
				player.FacingLeft=false;
				player.Skidding=false;
				player.OnGround=false;
				player.Invincible=0;
				int height=(level.Height-3)*Level.Tile-(int)(player.Y+player.Height);
				score+=height>=128?5000:height>=88?2000:height>=56?800:height>=16?400:100;
			}
			UpdateCamera();
		}

		void UpdateCamera()
		{
			cameraX=Math.Max(cameraX,Math.Min(player.X-112,level.Width*Level.Tile-256));
		}

		void HitBlock(int column,int row)
		{
			char c=level.Bump(column,row);
			if(c==' ') return;
			RectangleF above=new RectangleF(column*Level.Tile,(row-1)*Level.Tile,Level.Tile,Level.Tile);
			foreach(Goomba goomba in goombas) {
				if(!goomba.Alive||!goomba.Bounds.IntersectsWith(above)) continue;
				goomba.Kick();
				score+=100;
			}
			if(c=='?') {
				coins.Add(new Coin(column*Level.Tile,(row-1)*Level.Tile));
				score+=200;
				coinCount=(coinCount+1)%100;
			}
			if(c=='M') mushrooms.Add(new Mushroom(column*Level.Tile,row*Level.Tile));
		}

		void UpdateFinish()
		{
			if(finishStep==0) {
				bool landed=level.Collides(player.X,player.Y+2,Player.Width,player.Height);
				if(landed) player.Y=(float)Math.Floor((player.Y+2+player.Height)/Level.Tile)*Level.Tile-player.Height;
				else player.Y+=2;
				player.OnGround=landed;
				if(level.FlagOffset<(level.Height-5-level.FlagRow)*Level.Tile) level.FlagOffset+=2;
				else if(landed) finishStep=1;
			} else if(finishStep==1) {
				player.Update(level,false,true,false,false,cameraX);
				UpdateCamera();
				if(player.X>=level.CastleColumn*Level.Tile+34) {
					player.Hidden=true;
					finishStep=2;
				}
			} else if(time>0) {
				int step=Math.Min(time,2);
				time-=step;
				score+=step*50;
			} else {
				finishTimer++;
				if(finishTimer>120) {
					playing=false;
					StartLevel();
				}
			}
		}

		void MainFormKeyDown(object sender,KeyEventArgs e)
		{
			SetKey(e.KeyCode,true);
			if(e.KeyCode==Keys.Space&&!playing) {
				StartLevel();
				playing=true;
			}
		}

		void MainFormKeyUp(object sender,KeyEventArgs e)
		{
			SetKey(e.KeyCode,false);
		}

		void SetKey(Keys key,bool pressed)
		{
			if(key==Keys.Left) left=pressed;
			if(key==Keys.Right) right=pressed;
			if(key==Keys.ShiftKey) run=pressed;
			if(key==Keys.Up) jump=pressed;
		}

		void MainFormPaint(object sender,PaintEventArgs e)
		{
			Graphics g=e.Graphics;
			g.InterpolationMode=InterpolationMode.NearestNeighbor;
			g.PixelOffsetMode=PixelOffsetMode.Half;
			int offset=(int)(cameraX*Level.Scale);
			int backgroundWidth=Sprites.Get("background").Width;
			for(int x=-(offset/2%backgroundWidth);x<ClientSize.Width;x+=backgroundWidth) Sprites.Draw(g,"background",x,0);
			foreach(Mushroom mushroom in mushrooms) mushroom.Draw(g,offset);
			level.Draw(g,offset,frame);
			foreach(Coin coin in coins) coin.Draw(g,offset);
			foreach(Goomba goomba in goombas) goomba.Draw(g,offset,frame);
			player.Draw(g,offset);

			DrawText(g,"MARIO",72,48,1,"font");
			DrawText(g,score.ToString("000000"),72,72,1,"font");
			Sprites.Draw(g,"coin_icon",264,72);
			DrawText(g,"*"+coinCount.ToString("00"),288,72,1,"font");
			DrawText(g,"TOP",444,48,1,"font");
			DrawText(g,highScore.ToString("000000"),408,72,1,"font");
			DrawText(g,"TIME",600,48,1,"font");
			DrawText(g,time.ToString("000"),624,72,1,"font");
			if(playing) return;

			g.FillRectangle(Brushes.Black,78,126,624,216);
			g.FillRectangle(boardBrush,72,120,624,216);
			g.FillRectangle(lightBrush,72,120,624,6);
			g.FillRectangle(lightBrush,72,120,6,216);
			g.FillRectangle(Brushes.Black,72,330,624,6);
			g.FillRectangle(Brushes.Black,690,120,6,216);
			for(int i=0;i<4;i++) g.FillRectangle(lightBrush,87+i%2*588,135+i/2*180,6,6);
			DrawText(g,"MARIO",210,150,3,"font_dark");
			DrawText(g,"MARIO",204,144,3,"font_light");
			DrawText(g,"JUMP AND RUN",102,258,2,"font_dark");
			DrawText(g,"JUMP AND RUN",96,252,2,"font_light");
			if(frame/30%2==0) DrawText(g,"LEERTASTE ZUM STARTEN",132,396,1,"font");
			DrawText(g,"TOP- "+highScore.ToString("000000"),252,456,1,"font");
		}

		void DrawText(Graphics g,string text,int x,int y,int scale,string font)
		{
			Bitmap image=Sprites.Get(font);
			int size=8*Level.Scale;
			foreach(char c in text) {
				int index=glyphs.IndexOf(c);
				if(index>=0) g.DrawImage(image,new Rectangle(x,y,size*scale,size*scale),new Rectangle(index*size,0,size,size),GraphicsUnit.Pixel);
				x+=size*scale;
			}
		}
	}
}

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace MarioJumpAndRun
{
	public static class Sprites
	{
		static Dictionary<string,Bitmap> images=new Dictionary<string,Bitmap>();

		public static Bitmap Get(string name)
		{
			if(!images.ContainsKey(name)) images[name]=Load(name);
			return images[name];
		}

		public static void Draw(Graphics g,string name,int x,int y)
		{
			Bitmap image=Get(name);
			g.DrawImage(image,x,y,image.Width,image.Height);
		}

		static Bitmap Load(string name)
		{
			if(name.EndsWith("_flipped")) {
				Bitmap flipped=new Bitmap(Get(name.Substring(0,name.Length-8)));
				flipped.RotateFlip(RotateFlipType.RotateNoneFlipX);
				return flipped;
			}
			if(name.EndsWith("_upside")) {
				Bitmap flipped=new Bitmap(Get(name.Substring(0,name.Length-7)));
				flipped.RotateFlip(RotateFlipType.RotateNoneFlipY);
				return flipped;
			}
			string path=Path.Combine(Application.StartupPath,"Images",name+".png");
			using(Bitmap source=new Bitmap(path)) {
				int width=source.Width*Level.Scale;
				int height=source.Height*Level.Scale;
				if(name=="background") {
					height=15*Level.Tile*Level.Scale;
					width=source.Width*height/source.Height;
				}
				Bitmap result=new Bitmap(width,height,PixelFormat.Format32bppPArgb);
				using(Graphics g=Graphics.FromImage(result)) {
					g.InterpolationMode=InterpolationMode.NearestNeighbor;
					g.PixelOffsetMode=PixelOffsetMode.Half;
					g.DrawImage(source,0,0,width,height);
				}
				return result;
			}
		}
	}
}

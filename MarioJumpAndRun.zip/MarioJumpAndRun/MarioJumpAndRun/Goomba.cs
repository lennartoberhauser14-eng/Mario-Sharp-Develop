using System;

namespace MarioJumpAndRun
{
	public class Goomba
	{
		public float X,Y,SpeedY;
		public float SpeedX=-0.5f;
		public bool Active,Flat,Removed;
		private int flatTimer,animTick;

		public Goomba(int col, int row)
		{
			X=col*16;
			Y=row*16;
		}

		public void Move(Level level)
		{
			if (Flat)
			{
				flatTimer--;
				if (flatTimer<=0) Removed=true;
				return;
			}
			animTick++;

			X+=SpeedX;
			if (level.HitsSolid(X,Y,16,16))
			{
				if (SpeedX>0) X=(float)Math.Floor((X+16)/16)*16-16;
				else X=(float)Math.Floor(X/16)*16+16;
				SpeedX=-SpeedX;
			}

			SpeedY=Math.Min(4f,SpeedY+0.3f);
			Y+=SpeedY;
			if (level.HitsSolid(X,Y,16,16)){Y=(float)Math.Floor((Y+16)/16)*16-16; SpeedY=0;}
			if (Y>level.Rows*16) Removed=true;
		}

		public void Stomp()
		{
			Flat=true;
			flatTimer=30;
		}

		public int GetImageNumber()
		{
			if (Flat) return 2;
			return animTick/12%2;
		}
	}
}

using System;

namespace MarioJumpAndRun
{
	public class Goomba : Walker
	{
		public bool Active,Flat;
		private int flatTimer,animTick;

		public Goomba(int col, int row)
		{
			X=col*16;
			Y=row*16;
			SpeedX=-0.5f;
		}

		public void Move(Level level)
		{
			if (Flat)
			{
				flatTimer--;
				if (flatTimer<=0) Removed=true;
				return;
			}
			animTick++;
			Walk(level);
		}

		public void Stomp()
		{
			Flat=true;
			flatTimer=30;
		}

		public int GetImageNumber()
		{
			if (Flat) return 2;
			int frame = animTick / 12 % 2;
			return frame;
		}
	}
}

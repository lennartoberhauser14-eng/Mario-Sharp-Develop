using System;
using System.Drawing;

namespace MarioJumpAndRun
{
	public class Goomba
	{
		public const int Size=16;

		public float X;
		public float Y;
		public float VelocityX=-0.5f;
		public float VelocityY=0;
		public bool Active=false;
		public bool Flat=false;
		public bool Kicked=false;
		public bool Removed=false;
		int flatTimer=0;

		public Goomba(float x,float y)
		{
			X=x;
			Y=y;
		}

		public bool Alive
		{
			get { return Active&&!Flat&&!Kicked; }
		}

		public RectangleF Bounds
		{
			get { return new RectangleF(X,Y,Size,Size); }
		}

		public void Kick()
		{
			Kicked=true;
			VelocityY=-3.5f;
		}

		public void Update(Level level)
		{
			if(Flat) {
				flatTimer++;
				if(flatTimer>30) Removed=true;
				return;
			}
			VelocityY=Math.Min(VelocityY+0.3f,4);
			if(Kicked) {
				Y+=VelocityY;
				if(Y>level.Height*Level.Tile) Removed=true;
				return;
			}
			X+=VelocityX;
			if(level.Collides(X,Y,Size,Size)) {
				X-=VelocityX;
				VelocityX=-VelocityX;
			}
			Y+=VelocityY;
			if(level.Collides(X,Y,Size,Size)) {
				Y=(float)Math.Floor((Y+Size)/Level.Tile)*Level.Tile-Size;
				VelocityY=0;
			}
			if(Y>level.Height*Level.Tile) Removed=true;
		}

		public void Draw(Graphics g,int offset,int frame)
		{
			string name=Flat?"goomba_flat":Kicked?"goomba1_upside":"goomba"+(frame/10%2+1);
			Sprites.Draw(g,name,(int)(X*Level.Scale)-offset,(int)(Y*Level.Scale));
		}
	}
}

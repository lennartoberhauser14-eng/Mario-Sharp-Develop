using System;
using System.Drawing;

namespace MarioJumpAndRun
{
	public class Mushroom
	{
		public const int Size=16;

		public float X;
		public float Y;
		public float VelocityX=1;
		public float VelocityY=0;
		public bool Removed=false;
		float rise=16;

		public Mushroom(float x,float y)
		{
			X=x;
			Y=y;
		}

		public RectangleF Bounds
		{
			get { return new RectangleF(X,Y,Size,Size); }
		}

		public void Update(Level level)
		{
			if(rise>0) {
				rise-=0.5f;
				Y-=0.5f;
				return;
			}
			X+=VelocityX;
			if(level.Collides(X,Y,Size,Size)) {
				X-=VelocityX;
				VelocityX=-VelocityX;
			}
			VelocityY=Math.Min(VelocityY+0.3f,4);
			Y+=VelocityY;
			if(level.Collides(X,Y,Size,Size)) {
				Y=(float)Math.Floor((Y+Size)/Level.Tile)*Level.Tile-Size;
				VelocityY=0;
			}
			if(Y>level.Height*Level.Tile) Removed=true;
		}

		public void Draw(Graphics g,int offset)
		{
			Sprites.Draw(g,"mushroom",(int)(X*Level.Scale)-offset,(int)(Y*Level.Scale));
		}
	}
}

using System;

namespace MarioJumpAndRun
{
	public class Mushroom
	{
		public float X,Y,SpeedY;
		public float SpeedX=1f;
		public int RiseTimer=32;
		public bool Removed;

		public Mushroom(int col, int row)
		{
			X=col*16;
			Y=row*16;
		}

		public void Move(Level level)
		{
			if (RiseTimer>0){RiseTimer--; Y-=0.5f; return;}

			X+=SpeedX;
			if (level.HitsSolid(X,Y,16,16))
			{
				if (SpeedX>0) X=(float)Math.Floor((X+16)/16)*16-16;
				else X=(float)Math.Floor(X/16)*16+16;
				SpeedX=-SpeedX;
			}

			SpeedY=Math.Min(4f,SpeedY+0.3f);
			Y+=SpeedY;
			if (level.HitsSolid(X,Y,16,16)){Y=(float)Math.Floor((Y+16)/16)*16-16; SpeedY=0;}
			if (Y>level.Rows*16) Removed=true;
		}
	}
}

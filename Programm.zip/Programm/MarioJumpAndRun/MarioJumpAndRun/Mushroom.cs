using System;

namespace MarioJumpAndRun
{
	public class Mushroom : Walker
	{
		public Mushroom(int col, int row)
		{
			X=col*16;
			Y=row*16;
			SpeedX=1f;
		}
	}
}

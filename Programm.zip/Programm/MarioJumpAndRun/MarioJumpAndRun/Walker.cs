using System;
using System.Drawing;

namespace MarioJumpAndRun
{
	public class Walker
	{
		public float X,Y,SpeedX,SpeedY;
		public bool Removed;

		public RectangleF Box
		{
			get{return new RectangleF(X,Y,16,16);}
		}

		public void Walk(Level level)
		{
			X+=SpeedX;
			if (level.HitsSolid(X,Y,16,16))
			{
				if (SpeedX>0) X=(float)Math.Floor((X+16)/16)*16-16;
				else X=(float)Math.Floor(X/16)*16+16;
				SpeedX=-SpeedX;
			}

			SpeedY=Math.Min(4f,SpeedY+0.3f);
			Y+=SpeedY;
			if (level.HitsSolid(X,Y,16,16)){Y=(float)Math.Floor((Y+16)/16)*16-16; SpeedY=0;}
			if (Y>level.Rows*16) Removed=true;
		}
	}
}

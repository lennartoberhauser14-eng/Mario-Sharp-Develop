using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Windows.Forms;

namespace MarioJumpAndRun
{
	public partial class MainForm : Form
	{
		private Level level=new Level();
		private Player player;
		private List<Goomba> goombas=new List<Goomba>();
		private List<Mushroom> mushrooms=new List<Mushroom>();
		private Bitmap[] marioSmall=new Bitmap[5], marioSmallLeft=new Bitmap[5];
		private Bitmap[] marioBig=new Bitmap[5], marioBigLeft=new Bitmap[5];
		private Bitmap[] goombaImage=new Bitmap[3];
		private Bitmap ground,groundTop,brick,questionBlock,usedBlock,pipeTopLeft,pipeTopRight,pipeLeft,pipeRight;
		private Bitmap mushroomImage,coinImage,flag,flagPole,flagTop,background;
		private Bitmap screen=new Bitmap(256,240,PixelFormat.Format32bppPArgb);
		private Font hudFont=new Font("Consolas",22,FontStyle.Bold,GraphicsUnit.Pixel);
		private Font titleFont=new Font("Consolas",56,FontStyle.Bold,GraphicsUnit.Pixel);
		private string state="title";
		private int tick,score,highScore;
		private int coinCol,coinRow,coinTimer;
		private float cameraX;
		private bool leftDown,rightDown,jumpDown,jumpWasDown,dead;

		public MainForm()
		{
			InitializeComponent();
		}

		void MainForm_Load(object sender, EventArgs e)
		{
			this.DoubleBuffered=true;
			LoadImages();
			FlipImages();
			ResetLevel();
			timer1.Interval=15;
			timer1.Start();
		}

		void LoadImages()
		{
			string folder=Application.StartupPath+@"\Images\";
			if (!Directory.Exists(folder))
			{
				MessageBox.Show("Folder not found: "+folder,"Error");
				Environment.Exit(0);
			}
			string[] frames={"stand","walk1","walk2","walk3","jump"};
			for (int i = 0; i < 5; i++)
			{
				marioSmall[i]=LoadImage("mario_small_"+frames[i]);
				marioBig[i]=LoadImage("mario_big_"+frames[i]);
			}
			goombaImage[0]=LoadImage("goomba_walk1");
			goombaImage[1]=LoadImage("goomba_walk2");
			goombaImage[2]=LoadImage("goomba_flat");
			ground=LoadImage("ground");
			groundTop=LoadImage("ground_top");
			brick=LoadImage("brick");
			questionBlock=LoadImage("block_question");
			usedBlock=LoadImage("block_used");
			pipeTopLeft=LoadImage("pipe_top_left");
			pipeTopRight=LoadImage("pipe_top_right");
			pipeLeft=LoadImage("pipe_left");
			pipeRight=LoadImage("pipe_right");
			mushroomImage=LoadImage("mushroom");
			coinImage=LoadImage("coin");
			flag=LoadImage("flag");
			flagPole=LoadImage("flag_pole");
			flagTop=LoadImage("flag_top");
			if (File.Exists(folder+"background.png"))
			{
				Bitmap image=LoadImage("background");
				background=new Bitmap(image,image.Width*240/image.Height,240);
			}
			else background=CreatePlaceholderBackground();
		}

		Bitmap LoadImage(string name)
		{
			return (Bitmap)Image.FromFile(Application.StartupPath+@"\Images\"+name+".png");
		}

		void FlipImages()
		{
			for (int i = 0; i < 5; i++)
			{
				marioSmallLeft[i]=(Bitmap)marioSmall[i].Clone();
				marioSmallLeft[i].RotateFlip(RotateFlipType.RotateNoneFlipX);
				marioBigLeft[i]=(Bitmap)marioBig[i].Clone();
				marioBigLeft[i].RotateFlip(RotateFlipType.RotateNoneFlipX);
			}
		}

		Bitmap CreatePlaceholderBackground()
		{
			Bitmap image=new Bitmap(256,240);
			Graphics graphic=Graphics.FromImage(image);
			graphic.Clear(Color.FromArgb(143,199,255));
			graphic.FillEllipse(new SolidBrush(Color.FromArgb(70,160,80)),-30,170,140,90);
			graphic.FillEllipse(new SolidBrush(Color.FromArgb(108,196,106)),150,185,90,60);
			graphic.FillEllipse(Brushes.White,30,40,40,14);
			graphic.FillEllipse(Brushes.White,44,32,24,16);
			graphic.FillEllipse(Brushes.White,160,60,48,14);
			graphic.FillEllipse(Brushes.White,176,52,24,14);
			return image;
		}

		void ResetLevel()
		{
			level.Load();
			player=new Player(level.PlayerStart.X*16+2,level.PlayerStart.Y*16);
			goombas.Clear();
			foreach (Point start in level.GoombaStarts) goombas.Add(new Goomba(start.X,start.Y));
			mushrooms.Clear();
			cameraX=0;
			coinTimer=0;
			dead=false;
		}

		void StartGame()
		{
			score=0;
			ResetLevel();
			state="playing";
		}

		void Timer1Tick(object sender, EventArgs e)
		{
			UpdateGame();
			this.Invalidate();
		}

		void UpdateGame()
		{
			tick++;
			if (state=="title"&&jumpDown&&!jumpWasDown) StartGame();
			else if (state=="playing") UpdatePlaying();
			jumpWasDown=jumpDown;
		}

		void UpdatePlaying()
		{
			player.Move(leftDown,rightDown,jumpDown,level);
			if (player.BumpCol>=0) BumpBlock(player.BumpCol,player.BumpRow);
			MoveCamera();
			if (player.Invincible>0) player.Invincible--;
			if (coinTimer>0) coinTimer--;

			foreach (Goomba goomba in goombas)
			{
				goomba.Active=goomba.X>cameraX-32&&goomba.X<cameraX+272;
				if (goomba.Active){goomba.Move(level); CheckGoomba(goomba);}
			}
			goombas.RemoveAll(g => g.Removed);

			foreach (Mushroom mushroom in mushrooms)
			{
				mushroom.Walk(level);
				if (player.Box.IntersectsWith(mushroom.Box))
				{
					mushroom.Removed=true;
					Grow();
				}
			}
			mushrooms.RemoveAll(m => m.Removed);

			if (dead||player.Y>level.Rows*16) Die();
			else if (player.X+player.Width>=level.FlagColumn*16) Win();
		}

		void MoveCamera()
		{
			float target=player.X+player.Width/2f-128;
			float maxCamera=level.Columns*16-256;
			cameraX=Math.Max(0,Math.Min(target,maxCamera));
		}

		void BumpBlock(int col, int row)
		{
			char tile=level.GetTile(col,row);
			if (tile=='?'){level.SetTile(col,row,'U'); score+=200; coinCol=col; coinRow=row; coinTimer=20;}
			if (tile=='M'){level.SetTile(col,row,'U'); mushrooms.Add(new Mushroom(col,row-1));}
		}

		void CheckGoomba(Goomba goomba)
		{
			if (goomba.Flat) return;
			if (!player.Box.IntersectsWith(new RectangleF(goomba.X+2,goomba.Y+4,12,12))) return;
			if (player.SpeedY>0&&player.Y+player.Height<goomba.Y+12)
			{
				goomba.Stomp();
				player.SpeedY=jumpDown?-4f:-2.5f;
				score+=100;
			}
			else if (player.Invincible==0) Hurt();
		}

		void Grow()
		{
			score+=1000;
			if (player.Big) return;
			player.Big=true;
			player.Y-=16;
		}

		void Hurt()
		{
			if (!player.Big){dead=true; return;}
			player.Big=false;
			player.Y+=16;
			player.Invincible=120;
		}

		void Die()
		{
			if (score>highScore) highScore=score;
			score=0;
			ResetLevel();
		}

		void Win()
		{
			score+=1000;
			if (score>highScore) highScore=score;
			ResetLevel();
			state="title";
		}

		void MainFormPaint(object sender, PaintEventArgs e)
		{
			DrawWorld();
			Graphics graphic=e.Graphics;
			graphic.InterpolationMode=InterpolationMode.NearestNeighbor;
			graphic.PixelOffsetMode=PixelOffsetMode.Half;
			graphic.DrawImage(screen,0,0,this.ClientSize.Width,this.ClientSize.Height);
			DrawHud(graphic);
		}

		void DrawWorld()
		{
			Graphics graphic=Graphics.FromImage(screen);
			graphic.Clear(Color.Transparent);
			int camX=(int)cameraX;

			int bw=background.Width;
			int offset=((int)(cameraX*0.5)%bw+bw)%bw;
			for (int bx=-offset; bx<256; bx+=bw) Draw(graphic,background,bx,0);

			foreach (Mushroom mushroom in mushrooms) Draw(graphic,mushroomImage,mushroom.X-camX,mushroom.Y);

			int firstCol=camX/16;
			for (int col = firstCol; col <= firstCol+16; col++)
			{
				for (int row = 0; row < level.Rows; row++)
				{
					Bitmap image=GetTileImage(col,row);
					if (image!=null) Draw(graphic,image,col*16-camX,row*16);
				}
			}

			int poleX=level.FlagColumn*16-camX;
			Draw(graphic,flagTop,poleX,32);
			for (int row = 3; row < 12; row++) Draw(graphic,flagPole,poleX,row*16);
			Draw(graphic,flag,poleX-10,50);

			foreach (Goomba goomba in goombas) Draw(graphic,goombaImage[goomba.GetImageNumber()],goomba.X-camX,goomba.Y);
			if (coinTimer>0) Draw(graphic,coinImage,coinCol*16-camX,coinRow*16-16-(20-coinTimer));
			DrawPlayer(graphic,camX);
			graphic.Dispose();
		}

		void DrawPlayer(Graphics graphic, int camX)
		{
			if (player.Invincible/4%2==1) return;
			Bitmap image;
			if (player.Big&&player.FacingLeft) image=marioBigLeft[player.GetImageNumber()];
			else if (player.Big) image=marioBig[player.GetImageNumber()];
			else if (player.FacingLeft) image=marioSmallLeft[player.GetImageNumber()];
			else image=marioSmall[player.GetImageNumber()];
			Draw(graphic,image,player.X-2-camX,player.Y+player.Height-image.Height);
		}

		Bitmap GetTileImage(int col, int row)
		{
			if (col>=level.Columns) return null;
			char tile=level.GetTile(col,row);
			if (tile=='#'&&level.GetTile(col,row-1)=='#') return ground;
			if (tile=='#') return groundTop;
			if (tile=='B') return brick;
			if (tile=='?'||tile=='M') return questionBlock;
			if (tile=='U'||tile=='H') return usedBlock;
			if (tile=='<') return pipeTopLeft;
			if (tile=='>') return pipeTopRight;
			if (tile=='[') return pipeLeft;
			if (tile==']') return pipeRight;
			return null;
		}

		void Draw(Graphics graphic, Bitmap image, float x, float y)
		{
			graphic.DrawImage(image,new Rectangle((int)Math.Round(x),(int)Math.Round(y),image.Width,image.Height));
		}

		void DrawHud(Graphics graphic)
		{
			graphic.TextRenderingHint=TextRenderingHint.AntiAliasGridFit;
			int w=this.ClientSize.Width;
			DrawText(graphic,"SCORE "+score.ToString("000000"),hudFont,24,12,false);
			DrawText(graphic,"HI "+highScore.ToString("000000"),hudFont,w-196,12,false);
			if (state=="title")
			{
				graphic.FillRectangle(new SolidBrush(Color.FromArgb(150,0,0,0)),84,170,w-168,300);
				DrawText(graphic,"SUPER MARIO",titleFont,w/2,200,true);
				DrawText(graphic,"HI-SCORE "+highScore.ToString("000000"),hudFont,w/2,300,true);
				if (tick/30%2==0) DrawText(graphic,"PRESS UP TO START",hudFont,w/2,360,true);
				DrawText(graphic,"LEFT RIGHT MOVE  UP JUMP",hudFont,w/2,420,true);
			}
		}

		void DrawText(Graphics graphic, string text, Font font, float x, float y, bool center)
		{
			if (center) x-=graphic.MeasureString(text,font).Width/2;
			graphic.DrawString(text,font,Brushes.Black,x+3,y+3);
			graphic.DrawString(text,font,Brushes.White,x,y);
		}

		void MainFormKDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode==Keys.Left) leftDown=true;
			if (e.KeyCode==Keys.Right) rightDown=true;
			if (e.KeyCode==Keys.Up) jumpDown=true;
			if (e.KeyCode==Keys.Escape) this.Close();
		}

		void MainFormKUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode==Keys.Left) leftDown=false;
			if (e.KeyCode==Keys.Right) rightDown=false;
			if (e.KeyCode==Keys.Up) jumpDown=false;
		}

		void MainFormDeactivate(object sender, EventArgs e)
		{
			leftDown=false;
			rightDown=false;
			jumpDown=false;
		}
	}
}

/*
 * Created by SharpDevelop.
 * User: oble1108
 * Date: 06.10.2026
 * Time: 14:15
 *
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Drawing;

namespace Grafik
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		private const int FMax=9;
		private Color[] Farbe={Color.Black, Color.Gray, Color.Cyan, Color.Magenta, Color.Green, Color.Blue, Color.Yellow, Color.White, Color.Lavender};
		private GraphicsPath MousePath=new GraphicsPath();
		private int xPos=10, yPos=10;
		private bool aktiv=false;
		public MainForm()
		{
			InitializeComponent();
			this.DoubleBuffered=true;
		}
		private void Mainform_load(object sender, EventArgs e)
		{

		}
		private void Mainform_paint(object sender, PaintEventArgs e)
		{
			Graphics Grafik=e.Graphics;
			Random random=new Random();

			//----------Zeichen von linien und formen
//			Pen Pen=new Pen(Color.Black, 5);
//			int width=this.ClientSize.Width-67;
//			int height=this.ClientSize.Width-67;
//			Grafik.DrawLine(Pen,0,0,10,10);
//			Grafik.DrawRectangle(Pen,20,20,width,height);

			//------------Bild mit bunten Linien
//			int width=this.ClientSize.Width;
//			int height=this.ClientSize.Height;
//			Pen Pen=new Pen(Color.Black, 5);
//			for (int i = 0; i < 500; i++)
//			{
//				Pen.Color=Farbe[random.Next(0,FMax-1)];
//				Grafik.DrawLine(Pen, 0, i*4, width, height-i*4);
//				Grafik.DrawLine(Pen, i*6,0,width-i*4,height);
//			}

			//----------------bunte Punkte
//			SolidBrush Pinsel=new SolidBrush(Color.Black);
//			int width=this.ClientSize.Width;
//			int height=this.ClientSize.Height;
//			int x,y,z;
//			for (int i = 0; i < 500; i++)
//			{
//				x=random.Next(2,width);
//				y=random.Next(2,height);
//				z=random.Next(2,30);
//				Pinsel.Color=Farbe[random.Next(0,FMax-1)];
//				Grafik.FillEllipse(Pinsel, x,y,z,z);
//			}

			//----------Maus malen gemälde
//			using (Pen pen=new Pen(Color.Black,2))
//			{
//				Grafik.DrawPath(pen,MousePath);
//			}
			Pen pen=new Pen(Color.Black,2);
			Grafik.DrawEllipse(pen,xPos,yPos,30,30);
			
		}
		void ShowImage()
		{
		
		}
		void MainformKDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode==Keys.Right)xPos+=20;
			if (e.KeyCode==Keys.Left) xPos-=20;
			if (e.KeyCode==Keys.Up) yPos-=20;
			if (e.KeyCode==Keys.Down) yPos+=20;
			this.Invalidate();
		}
		

//		void MainformMDown(object sender, MouseEventArgs e)
//		{
//			aktiv=true;
//			xPos=e.X;
//			yPos=e.Y;
//		}
//		void MainformMMove(object sender, MouseEventArgs e)
//		{
//			if (!aktiv)return;
//			int x=e.X;
//			int y=e.Y;
//			MousePath.StartFigure();
//			MousePath.AddLine(xPos,yPos,x,y);
//			xPos=x;
//			yPos=y;
//			this.Invalidate();
//		}
//		void MainformMUp(object sender, MouseEventArgs e)
//		{
//			aktiv=false;
//		}
		
	}
}

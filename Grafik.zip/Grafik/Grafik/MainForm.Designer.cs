﻿/*
 * Created by SharpDevelop.
 * User: oble1108
 * Date: 06.10.2026
 * Time: 14:15
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Grafik
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.SuspendLayout();
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 261);
			this.KeyPreview = true;
			this.Name = "MainForm";
			this.Text = "Grafik";
			this.Load += new System.EventHandler(this.Mainform_load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Mainform_paint);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainformKDown);
			this.ResumeLayout(false);

		}
	}
}
